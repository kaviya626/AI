/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'serif': ['Playfair Display', 'serif'],
        'sans': ['Poppins', 'sans-serif'],
      },
      colors: {
        'cream': '#FFF5E1',
        'cream-dark': '#F8E8D5',
        'teal': '#1A3C34',
        'coral': '#FF6F61',
        'coral-dark': '#E65A50',
        'yellow': '#FFC107',
        'divider': '#D3C8A5',
      },
    },
  },
  plugins: [],
};