import React from 'react';
import { Mail, Linkedin, Instagram, Dribbble } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left Side - Intro Section */}
      <div className="flex-1 bg-gradient-to-br from-cream to-cream-dark px-6 lg:px-10 py-12 flex flex-col justify-center relative">
        <div className="max-w-lg mx-auto lg:mx-0">
          <h1 className="font-serif font-bold text-4xl md:text-5xl lg:text-6xl text-teal leading-tight tracking-wide mb-6">
            Creativity That <em className="italic">Speaks</em>
          </h1>
          
          <p className="font-sans text-base md:text-lg text-teal leading-relaxed mb-6 tracking-wide">
            I'm Alex Carter, a freelance creative specializing in graphic design, photography, and writing. 
            My work blends bold ideas with professional execution to bring your vision to life.
          </p>
          
          <p className="font-serif text-xl text-yellow font-medium tracking-wider">
            Bold. Unique. Yours.
          </p>
        </div>
      </div>

      {/* Vertical Divider */}
      <div className="hidden lg:block w-px bg-divider"></div>

      {/* Right Side - Navigation & CTA */}
      <div className="flex-1 bg-teal px-6 lg:px-10 py-12 flex flex-col relative">
        {/* Header with Navigation and CTA */}
        <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-12 gap-6 lg:gap-0">
          <nav>
            <ul className="flex flex-wrap gap-6 lg:gap-8">
              {['WORK', 'ABOUT', 'BLOG'].map((item) => (
                <li key={item}>
                  <a 
                    href="#" 
                    className="font-sans text-sm font-medium text-cream tracking-wider hover:text-yellow transition-all duration-300"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          
          <button className="bg-coral text-white font-sans font-medium px-6 py-3 rounded-md hover:bg-coral-dark hover:scale-105 transition-all duration-300 shadow-lg">
            View My Work
          </button>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex flex-col justify-center max-w-lg mx-auto lg:mx-0">
          <h2 className="font-serif text-2xl md:text-3xl text-cream mb-6 leading-tight">
            Ready to create something extraordinary?
          </h2>
          
          <p className="font-sans text-base md:text-lg text-cream leading-relaxed opacity-90 mb-8">
            Let's collaborate to craft compelling visual stories that captivate your audience 
            and elevate your brand to new heights.
          </p>
        </div>

        {/* Footer */}
        <footer className="mt-12 lg:mt-0">
          <div className="space-y-4">
            <div className="flex flex-wrap gap-6">
              <a 
                href="#" 
                className="flex items-center gap-2 text-cream hover:text-yellow transition-colors duration-300"
              >
                <Mail size={16} />
                <span className="font-sans text-sm">Email</span>
              </a>
              <a 
                href="#" 
                className="flex items-center gap-2 text-cream hover:text-yellow transition-colors duration-300"
              >
                <Linkedin size={16} />
                <span className="font-sans text-sm">LinkedIn</span>
              </a>
              <a 
                href="#" 
                className="flex items-center gap-2 text-cream hover:text-yellow transition-colors duration-300"
              >
                <Instagram size={16} />
                <span className="font-sans text-sm">Instagram</span>
              </a>
              <a 
                href="#" 
                className="flex items-center gap-2 text-cream hover:text-yellow transition-colors duration-300"
              >
                <Dribbble size={16} />
                <span className="font-sans text-sm">Dribbble</span>
              </a>
            </div>
            
            <div className="border-t border-cream/20 pt-4 mt-6">
              <p className="font-sans text-sm text-cream/80">
                ©2025 Alex Carter Studio • All Rights Reserved
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;